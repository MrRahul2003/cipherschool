import React from "react";

const FullScreen = (props) => {
  console.log(props);
  return (
    <>
      <div className="container">
        <div className="col-md-12">
          <div className="ibox float-e-margins float-right">
            <div className="ibox-title">
              <h5>Video window</h5>
              <button
                type="button"
                className="btn-close"
                aria-label="Close"
                onClick={() => props.setplay(false)}
              />
            </div>
            <div className="ibox-content mt-2">
              <video preload="auto" width="320" height="240" controls>
                <source
                  src={`${"http://localhost:5000"}${props.playVideo.videos}`}
                />
                Your browser does not support the video tag
              </video>

            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FullScreen;
