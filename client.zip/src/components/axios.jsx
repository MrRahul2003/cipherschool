// All axios api here of students
import axios from "axios";

//backend's url
const url = "http://localhost:5000";

const create = async (data) => {
  try {
    console.log("create new video sending data", data);
    const response = await axios.post(`${url}/video/create`, data);
    console.log("create new video receiving data", response);
    return response;
  } catch (error) {
    console.log("Error while create API", error.message);
  }
};

const getVideos = async () => {
  try {
    const response = await axios.get(`${url}/video/get`);
    console.log("getvideos", response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getvideos API", error.message);
  }
};

export { create, getVideos };
