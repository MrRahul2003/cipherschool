import React, { useState, useEffect } from "react";
import { getVideos } from "./axios";
import VideoList from "./VideoList";

const UploadList = (props) => {
  const [allVideos, setallVideos] = useState([]);
  const getAllVideos = async () => {
    const response = await getVideos();
    console.log("all videos are", response);
    setallVideos(response);
  };

  useEffect(() => {
    getAllVideos();
  }, [props.submitForm]);

  return (
    <>
      <div className="col-md-12">
        <div className="ibox float-e-margins">
          <div className="ibox-title">
            <h5>All Videos</h5>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="row text-center">
          {allVideos.map((video, i) => {
            return <VideoList key={i} video={video} setplay={props.setplay} setplayVideo={props.setplayVideo} />;
          })}
        </div>
      </div>
    </>
  );
};

export default UploadList;
