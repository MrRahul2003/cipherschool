import React, { useState } from "react";
import FullScreen from "./FullScreen";
import UploadForm from "./UploadForm";
import UploadList from "./UploadList";
import "./Video.css";

const Video = () => {
  const [submitForm, setsubmitForm] = useState(false);
  const [play, setplay] = useState(false);
  const [playVideo, setplayVideo] = useState({});
  return (
    <>
      <div className="container mt-4">
        <div className="row">
          <UploadForm setsubmitForm={setsubmitForm} submitForm={submitForm} />
          {play ? (
            <>
              <FullScreen setplay={setplay} playVideo={playVideo} />
              <UploadList submitForm={submitForm} setplay={setplay} />
            </>
          ) : (
            <UploadList submitForm={submitForm} setplay={setplay} setplayVideo={setplayVideo} />
          )}
        </div>
      </div>
    </>
  );
};

export default Video;
