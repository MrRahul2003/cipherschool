import React from "react";

const VideoList = (props) => {
  return (
    <>
      <div
        className="col-xl-3 col-sm-6 mb-5"
        onClick={() => {
          props.setplay(true);
          props.setplayVideo(props.video)
        }}
      >
        <div className="bg-white rounded shadow-sm py-5 px-4">
          <h5 className="mb-0">{props.video.name}</h5>
          <video preload="auto" width="320" height="240" controls>
            <source src={`${"http://localhost:5000"}${props.video.videos}`} />
            Your browser does not support the video tag
          </video>
        </div>
      </div>
    </>
  );
};

export default VideoList;
