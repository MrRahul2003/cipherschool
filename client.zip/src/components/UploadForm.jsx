import React, { useState } from "react";
import { create } from "./axios";

const UploadForm = (props) => {
  const [name, setName] = useState("");
  const [videos, setVideos] = useState([]);

  const handleSubmit = async (e) => {
    let formdata = new FormData();
    e.preventDefault();
    for (let key in videos) {
      formdata.append("videos", videos[key]);
    }
    formdata.append("name", name);

    const response = await create(formdata);
    props.setsubmitForm(!props.submitForm);
    console.log("creating new video", response);
  };

  return (
    <>
      <div className="col-md-12">
        <div className="ibox float-e-margins">
          <div className="ibox-title">
            <h5>Video upload</h5>
          </div>
          <div className="ibox-content profile-content">
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Enter Video Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  name="name"
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Video</label>
                <input
                  type="file"
                  className="form-control"
                  name="videos"
                  id="videos"
                  multiple
                  accept=".mp4, .mkv"
                  onChange={(e) => setVideos(e.target.files)}
                />
              </div>

              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default UploadForm;
